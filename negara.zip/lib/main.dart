import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'tambah_negara_page.dart';
import 'edit_negara_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi Data Negara',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: NegaraPage(),
    );
  }
}

class NegaraPage extends StatefulWidget {
  @override
  _NegaraPageState createState() => _NegaraPageState();
}

class _NegaraPageState extends State<NegaraPage> {
  List<dynamic> dataNegara = [];

  Future<void> fetchData() async {
    final response = await http.get(Uri.parse('http://localhost:3000/negara'));
    if (response.statusCode == 200) {
      setState(() {
        dataNegara = json.decode(response.body);
      });
    } else {
      throw Exception('Gagal memuat data');
    }
  }

  Future<void> hapusNegara(String kodeNegara) async {
    final response = await http.delete(
      Uri.parse('http://localhost:3000/negara/$kodeNegara'),
    );
    if (response.statusCode == 200) {
      fetchData(); // Refresh daftar negara
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menghapus data')),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Data Negara')),
      body: dataNegara.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: dataNegara.length,
              itemBuilder: (context, index) {
                final negara = dataNegara[index];
                return Card(
                  child: ListTile(
                    leading: Image.network(negara['gambar_bendera']),
                    title: Text(negara['nama_negara']),
                    subtitle: Text(negara['deskripsi_negara']),
                    trailing: IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () => hapusNegara(negara['kode_negara']),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => EditNegaraPage(negara: negara),
                        ),
                      ).then((_) => fetchData());
                    },
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => TambahNegaraPage()),
          ).then((_) => fetchData());
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
