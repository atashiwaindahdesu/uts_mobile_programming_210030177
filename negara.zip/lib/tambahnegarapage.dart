import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class TambahNegaraPage extends StatefulWidget {
  @override
  _TambahNegaraPageState createState() => _TambahNegaraPageState();
}

class _TambahNegaraPageState extends State<TambahNegaraPage> {
  final TextEditingController kodeController = TextEditingController();
  final TextEditingController namaController = TextEditingController();
  final TextEditingController deskripsiController = TextEditingController();
  final TextEditingController gambarController = TextEditingController();

  Future<void> tambahNegara() async {
    final response = await http.post(
      Uri.parse('http://localhost:3000/negara'),
      headers: {'Content-Type': 'application/json'},
      body: '''
      {
        "kode_negara": "${kodeController.text}",
        "nama_negara": "${namaController.text}",
        "deskripsi_negara": "${deskripsiController.text}",
        "gambar_bendera": "${gambarController.text}"
      }
      ''',
    );

    if (response.statusCode == 201) {
      Navigator.pop(context); // Kembali ke halaman utama
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menambahkan data')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tambah Negara')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: kodeController,
              decoration: InputDecoration(labelText: 'Kode Negara'),
            ),
            TextField(
              controller: namaController,
              decoration: InputDecoration(labelText: 'Nama Negara'),
            ),
            TextField(
              controller: deskripsiController,
              decoration: InputDecoration(labelText: 'Deskripsi Negara'),
            ),
            TextField(
              controller: gambarController,
              decoration: InputDecoration(labelText: 'URL Gambar Bendera'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: tambahNegara,
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}
