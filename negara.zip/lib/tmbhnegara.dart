import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class EditNegaraPage extends StatefulWidget {
  final Map<String, dynamic> negara;

  EditNegaraPage({required this.negara});

  @override
  _EditNegaraPageState createState() => _EditNegaraPageState();
}

class _EditNegaraPageState extends State<EditNegaraPage> {
  late TextEditingController namaController;
  late TextEditingController deskripsiController;
  late TextEditingController gambarController;

  @override
  void initState() {
    super.initState();
    namaController = TextEditingController(text: widget.negara['nama_negara']);
    deskripsiController =
        TextEditingController(text: widget.negara['deskripsi_negara']);
    gambarController =
        TextEditingController(text: widget.negara['gambar_bendera']);
  }

  Future<void> editNegara() async {
    final response = await http.put(
      Uri.parse('http://localhost:3000/negara/${widget.negara['kode_negara']}'),
      headers: {'Content-Type': 'application/json'},
      body: '''
      {
        "kode_negara": "${widget.negara['kode_negara']}",
        "nama_negara": "${namaController.text}",
        "deskripsi_negara": "${deskripsiController.text}",
        "gambar_bendera": "${gambarController.text}"
      }
      ''',
    );

    if (response.statusCode == 200) {
      Navigator.pop(context); // Kembali ke halaman utama
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memperbarui data')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Edit Negara')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: namaController,
              decoration: InputDecoration(labelText: 'Nama Negara'),
            ),
            TextField(
              controller: deskripsiController,
              decoration: InputDecoration(labelText: 'Deskripsi Negara'),
            ),
            TextField(
              controller: gambarController,
              decoration: InputDecoration(labelText: 'URL Gambar Bendera'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: editNegara,
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}